package icecream;

public class IceCreamConeException extends Exception {
	IceCreamConeException(String message) {
		super(message);
	}
}
